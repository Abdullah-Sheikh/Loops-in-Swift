import UIKit

var num = 0
// while loop .....
while num < 10
{
    num=num+1
    
}


// for loop .....
for number in 0...10
{
    number
}


for number in [2,4,7,9]
{
    number
}

